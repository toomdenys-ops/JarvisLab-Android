# Boby V4.0 — interface da referência

A V4.0 recria a tela da captura enviada: fundo preto, rosto azul do Boby, quatro indicadores do aparelho, abas **Chat / Telefone / Enfoque / Agenda / Ajustes**, sugestões de conversa e campo arredondado com microfone e envio. Os recursos do app, a memória, as tarefas, os arquivos, a voz e a cápsula flutuante foram mantidos.

Também foi corrigida a ponte JavaScript–Android que impedia os botões e o chat de responderem. Sem um modelo local ou chave DeepSeek, o Boby ainda responde cumprimentos e mostra como ativar os outros motores.

## Instalar

1. Baixe o APK Boby V4.0.
2. Instale sobre a versão anterior; o identificador do app foi mantido para preservar os dados.
3. Para ativar a cápsula sobre outros aplicativos, abra **Ajustes → Cápsula flutuante → Ativar** e autorize a sobreposição nas configurações do Android.

## Compilar no GitHub

Abra **Actions → BOBY V4.0 • Interface da referência → Run workflow**. Ao terminar, baixe o artefato `BobyLab-V4.0-Interface-Boby-APK`.
