package br.com.jarvislab.autonomo

import android.app.Notification
import android.app.Notification.Action
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Locale

/** Opt-in reply assistant. It reads only WhatsApp notification data and replies via its notification action. */
class WhatsAppAutoReplyService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in WHATSAPP_PACKAGES) return
        val prefs = getSharedPreferences("jarvis_data", MODE_PRIVATE)
        if (!prefs.getBoolean("whatsEnabled", false)) return

        val notification = sbn.notification ?: return
        val extras = notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() || text.isBlank()) return

        val allowed = prefs.getString("whatsContacts", "").orEmpty()
            .split(',', ';', '\n')
            .map { it.trim().lowercase(Locale.ROOT) }
            .filter { it.isNotEmpty() }
        if (allowed.isEmpty() || allowed.none { it == title.lowercase(Locale.ROOT) }) return

        val reply = prefs.getString("whatsReply", "").orEmpty().trim().take(300)
        if (reply.isBlank()) return
        val action = notification.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return
        val remoteInputs = action.remoteInputs ?: return
        val cooldownKey = "whatsLastReply:" + title.lowercase(Locale.ROOT).hashCode()
        val now = System.currentTimeMillis()
        val last = prefs.getLong(cooldownKey, 0L)
        if (now - last < COOLDOWN_MS) return

        val intent = Intent()
        val results = Bundle().apply {
            remoteInputs.forEach { input -> putCharSequence(input.resultKey, reply) }
        }
        RemoteInput.addResultsToIntent(remoteInputs, intent, results)
        try {
            action.actionIntent.send(this, 0, intent)
            // Store only a timestamp per allowed contact, never message contents.
            prefs.edit().putLong(cooldownKey, now).apply()
        } catch (_: PendingIntent.CanceledException) {
            // The notification action can expire before delivery; ignore and wait for the next one.
        } catch (_: Exception) {
            // Fail closed: do not attempt any alternate UI automation.
        }
    }

    companion object {
        private val WHATSAPP_PACKAGES = setOf("com.whatsapp", "com.whatsapp.w4b")
        private const val COOLDOWN_MS = 30 * 60 * 1000L
    }
}
