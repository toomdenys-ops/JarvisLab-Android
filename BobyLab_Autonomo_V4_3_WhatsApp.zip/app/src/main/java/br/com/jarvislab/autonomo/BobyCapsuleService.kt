package br.com.jarvislab.autonomo

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView

class BobyCapsuleService : Service() {
    private var windowManager: WindowManager? = null
    private var capsule: View? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val enabled = getSharedPreferences("jarvis_data", MODE_PRIVATE).getBoolean("capsuleEnabled", false)
        when {
            !enabled || !Settings.canDrawOverlays(this) -> { removeCapsule(); stopSelf(); return START_NOT_STICKY }
            intent?.action == ACTION_HIDE || MainActivity.isForeground -> removeCapsule()
            else -> showCapsule()
        }
        return START_STICKY
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun showCapsule() {
        if (capsule != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(12), 0)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(28).toFloat()
                setColor(Color.rgb(5, 8, 12))
                setStroke(dp(1), Color.rgb(10, 47, 67))
            }
            contentDescription = "Boby. Toque para conversar por voz."
            elevation = dp(5).toFloat()
        }

        root.addView(FaceView(), LinearLayout.LayoutParams(dp(38), dp(30)))
        val labels = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(13), 0, 0, 0)
        }
        labels.addView(TextClock(this).apply {
            format12Hour = "HH:mm"
            format24Hour = "HH:mm"
            textSize = 14f
            setTextColor(Color.rgb(242, 243, 247))
            includeFontPadding = false
        })
        labels.addView(TextView(this).apply {
            text = "Toque para conversar com o Boby"
            textSize = 12f
            setTextColor(Color.rgb(144, 152, 168))
            maxLines = 1
            includeFontPadding = false
        })
        root.addView(labels, LinearLayout.LayoutParams(0, dp(38), 1f))
        root.addView(TextView(this).apply {
            text = "BOBY"
            textSize = 13f
            setTextColor(Color.rgb(21, 157, 241))
            gravity = Gravity.CENTER
            setPadding(dp(5), 0, 0, 0)
        }, LinearLayout.LayoutParams(dp(47), dp(38)))

        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels - dp(28)).coerceAtLeast(dp(260)),
            dp(48),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(14)
            y = dp(46)
        }

        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0f; var startY = 0f; var originalX = 0; var originalY = 0; var dragged = false
        root.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    originalX = params.x; originalY = params.y; dragged = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - startX; val dy = event.rawY - startY
                    if (kotlin.math.abs(dx) > touchSlop || kotlin.math.abs(dy) > touchSlop) dragged = true
                    if (dragged) {
                        params.x = (originalX + dx).toInt().coerceIn(0, (resources.displayMetrics.widthPixels - params.width).coerceAtLeast(0))
                        params.y = (originalY + dy).toInt().coerceIn(dp(24), (resources.displayMetrics.heightPixels - params.height).coerceAtLeast(dp(24)))
                        runCatching { wm.updateViewLayout(root, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) startActivity(Intent(this, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        putExtra("jarvis_capsule_voice", true)
                    })
                    true
                }
                else -> true
            }
        }

        runCatching { wm.addView(root, params); capsule = root }.onFailure { stopSelf() }
    }

    private fun removeCapsule() {
        capsule?.let { view -> runCatching { windowManager?.removeView(view) } }
        capsule = null
        windowManager = null
    }

    override fun onDestroy() {
        removeCapsule()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private inner class FaceView : View(this) {
        private val blue = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(22, 142, 242) }
        private val cyan = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(8, 195, 220); style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat(); strokeCap = Paint.Cap.ROUND }
        private val yellow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 209, 60) }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val d = resources.displayMetrics.density
            canvas.drawRoundRect(RectF(6*d, 2*d, 16*d, 16*d), 5*d, 5*d, blue)
            canvas.drawRoundRect(RectF(21*d, 2*d, 31*d, 16*d), 5*d, 5*d, blue)
            canvas.drawCircle(32*d, 16*d, 3*d, yellow)
            canvas.drawArc(RectF(13*d, 17*d, 25*d, 27*d), 10f, 160f, false, cyan)
        }
    }

    companion object { const val ACTION_HIDE = "br.com.jarvislab.autonomo.HIDE_BOBY_CAPSULE" }
}
